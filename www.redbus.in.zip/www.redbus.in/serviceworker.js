// initializing moengage service worker
importScripts("https://cdn.moengage.com/webpush/releases/serviceworker_cdn.min.latest.js");